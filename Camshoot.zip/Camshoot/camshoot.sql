-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 19, 2018 at 03:47 AM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.2.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `camshoot`
--

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE `registration` (
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `psw` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`name`, `email`, `psw`) VALUES
('Hinaben Parmar', '1@g.com', '2'),
('Hardik Chauhan', 'h@g.com', '1'),
('Hardik Chauhan', 'hardik8c@gmail.com', '1'),
('Hardik Chauhan', 'hc9555@gmail.com', '1'),
('Hardik Chauhan', 'hchauhan8866762369@gmail.com', '1'),
('Hinaben Parmar', 'hyc@gmail.com', '1');

-- --------------------------------------------------------

--
-- Table structure for table `upload_img`
--

CREATE TABLE `upload_img` (
  `img_name` varchar(500) NOT NULL,
  `img_path` varchar(500) NOT NULL,
  `img_type` varchar(500) NOT NULL,
  `mail_id` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `upload_img`
--

INSERT INTO `upload_img` (`img_name`, `img_path`, `img_type`, `mail_id`) VALUES
('10 marla house map.jpg', '../users/hc9555@gmail.com10 marla house map.jpg', 'image/jpeg', 'hc9555@gmail.com'),
('span-new-3d-front-elevation-com-beautiful-modern-1-kanal-home-3d-front-home-design-720x540-117kb.jpg', '../users/hc9555@gmail.comspan-new-3d-front-elevation-com-beautiful-modern-1-kanal-home-3d-front-home-design-720x540-117kb.jpg', 'image/jpeg', 'hc9555@gmail.com'),
('Terrace$mail_idoverlooking$mail_idthe$mail_idsea$mail_idthe$mail_idperfect$mail_idhome$mail_id5120x3200.jpg', '../users/hc9555@gmail.com/Terrace-overlooking-the-sea-the-perfect-home_5120x3200.jpg', 'image/jpeg', 'hc9555@gmail.com'),
('Terrace$mail_idoverlooking$mail_idthe$mail_idsea$mail_idthe$mail_idperfect$mail_idhome$mail_id5120x3200.jpg', '../users/hc9555@gmail.com/Terrace-overlooking-the-sea-the-perfect-home_5120x3200.jpg', 'image/jpeg', 'hc9555@gmail.com'),
('10$mail_idmarla$mail_idhouse$mail_idmap.jpg', '../users/hc9555@gmail.com/10 marla house map.jpg', 'image/jpeg', 'hc9555@gmail.com'),
('13619796$mail_id1736320896649832$mail_id7205204918840398503$mail_idn.jpg', '../users/hchauhan8866762369@gmail.com/13619796_1736320896649832_7205204918840398503_n.jpg', 'image/jpeg', 'hchauhan8866762369@gmail.com'),
('15220090$mail_id1803354136613174$mail_id8435628970291548725$mail_idn.jpg', '../users/hchauhan8866762369@gmail.com/15220090_1803354136613174_8435628970291548725_n.jpg', 'image/jpeg', 'hchauhan8866762369@gmail.com'),
('15622473$mail_id1812795489002372$mail_id333958520172922690$mail_idn.jpg', '../users/hchauhan8866762369@gmail.com/15622473_1812795489002372_333958520172922690_n.jpg', 'image/jpeg', 'hchauhan8866762369@gmail.com'),
('download.jpg', '../users/hc9555@gmail.com/download.jpg', 'image/jpeg', 'hc9555@gmail.com'),
('download.jpg', '../users/hc9555@gmail.com/download.jpg', 'image/jpeg', 'hc9555@gmail.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `registration`
--
ALTER TABLE `registration`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `upload_img`
--
ALTER TABLE `upload_img`
  ADD KEY `mail_id` (`mail_id`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `upload_img`
--
ALTER TABLE `upload_img`
  ADD CONSTRAINT `upload_img_ibfk_1` FOREIGN KEY (`mail_id`) REFERENCES `registration` (`email`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
