<?php
  session_start();
  require_once('dbconfig/config.php');
?>
  <?php

if(isset($_POST['register']))
{
  @$fullname =$_POST['name'];
  @$email=$_POST['email'];
  @$password=$_POST['psw'];
  @$cpassword=$_POST['psw-repeat'];
  
 
  if($password==$cpassword)
  {
    $query = "SELECT * FROM `registration` WHERE email='$email'";
    $query_run = mysqli_query($con,$query);
    if($query_run)
      {
        if(mysqli_num_rows($query_run)>1)
        {
          echo '<p class="bg-danger msg-block">Registration Unsuccessful due to server error. Please try later</p>';
        }
        else
        {
          $query1 = "INSERT INTO registration (name,email,psw) VALUES ('$fullname','$email','$password')";
          $query_run1 = mysqli_query($con,$query1);
          if($query_run1)
          {
            $dir = "../users/$email/";
            if(!is_dir($dir)){
                                mkdir($dir,"0777", true);
                             }
                  header("Location: homepage.php");
                  $_SESSION['name'] = $fullname; 
                  $_SESSION['email'] = $email;
                  $_SESSION['psw'] = $password; 
          }
          else
          {
            echo '<script type="text/javascript">alert("This Email Already exists...!")</script>';
          }
        }
      }
      else
      {
        echo '<script type="text/javascript">alert("DB ERROR")</script>';
      }
  }
  else
  {
    echo '<script type="text/javascript">alert("Password and Confirm Password do not match")</script>';
  }
        
  }
  else
  {
  }
?>


<!DOCTYPE html>

<html>
<head>
<title>CAMSHOOT | Registration</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link href="../layout/styles/layout.css" rel="stylesheet" type="text/css" media="all">
<style type="text/css">
  input[type=text], input[type=password] {
    width: 100%;
    padding: 15px;
    margin: 5px 0 22px 0;
    display: inline-block;
    border: none;
    background: #f1f1f1;
}

input[type=text]:focus, input[type=password]:focus {
    background-color: #ddd;
    outline: none;
}

hr {
    border: 1px solid #f1f1f1;
    margin-bottom: 25px;
}

/* Set a style for all buttons */
button {

    background-color: #EA2C5A;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    cursor: pointer;
    width: 100%;
    opacity: 0.8;
}

button:hover {
    opacity:1;
}

/* Extra styles for the cancel button */


/* Float cancel and signup buttons and add an equal width */
.signupbtn,
.loginbtn{
  
  width: 100%;
}

/* Add padding to container elements */
.container {
    padding: 16px;
}

/* Clear floats */
.clearfix::after {
    content: "";
    clear: both;
    display: table;
}

</style>
</head>
<body id="top">
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- Top Background Image Wrapper -->
<div class="bgded overlay" style="background-image:url('../images/demo/backgrounds/01.jpg');"> 
  <!-- ################################################################################################ -->
  <div class="wrapper row0">
    <div id="topbar" class="hoc clear"> 
      
      <div class="fl_left">
        <ul class="nospace">
          <li><i class="fa fa-phone"></i> +64 223944532</li>
          <li><i class="fa fa-envelope-o"></i> hc9555@gmail.com</li>
        </ul>
      </div>
      <div class="fl_right">
        <ul class="nospace">
          <li><a href="../index.html"><i class="fa fa-lg fa-home"></i></a></li>
          <li><a href="login.php">Login</a></li>
          <li class="active"><a href="user.php">Register</a></li>
        </ul>
      </div>
      <!-- ################################################################################################ -->
    </div>
  </div>
  </div>
  <!-- ################################################################################################ -->
  <!-- ################################################################################################ -->
  <!-- ################################################################################################ -->
  <div class="wrapper row1">
    <header id="header" class="hoc clear"> 
      <!-- ################################################################################################ -->
      <div id="logo" class="fl_left">
        <h1><a href="../index.html"><img src="../logo.png" alt="logo" style="width: 250px; height: auto;"></a></h1>
      </div>
      <nav id="mainav" class="fl_right"><br>
        <ul class="clear">
          <li><a href="../index.html">Home</a></li>
          <li><a class="drop" href="#">Gallery</a>
            <ul>
              <li><a href="gallery.html">Fashion & Modeling</a></li>

              <li><a href="nature.html">Nature</a></li>
              <li><a href="b&w.html">Black and White</a></li>
              
            </ul>
          </li>

           <li><a href="events.html">Competition & Events</a></li>

           <li><a href="book.php">Book a photographer</a></li>
          <li><a href="contact.php">Contact Us</a></li>
        </ul>
      </nav>
      <!-- ################################################################################################ -->
    </header>
  </div>
  <!-- ################################################################################################ -->
</div>
<!-- End Top Background Image Wrapper -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<div class="wrapper row2">
  <div id="breadcrumb" class="hoc clear"> 
    <!-- ################################################################################################ -->
    <ul>
      <li><a href="../index.html">Home</a></li>
      <li><a href="user.php">Register</a></li>
    </ul>
    <!-- ################################################################################################ -->
  </div>
</div>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<div class="wrapper row3">
  <main class="hoc container clear" > 
    
    
      <!-- #################################################################################-->
    <div class="reg1" style="float:left; width:100%; padding: 20px; text-align: center;">
      
      <div class="regis">
        <form action="user.php" method="post">
        <h1>Sign Up</h1>
    <p>Please fill in this form to create an account.</p>
    <hr>
    <label for="name"><b>Name</b></label>
    <input type="text" placeholder="Full name" name="name" required>


    <label for="email"><b>Email</b></label>
    <input type="text" placeholder="Enter Email" name="email" required>

    <label for="psw"><b>Password</b></label>
    <input type="password" placeholder="Enter Password" name="psw" required>

    <label for="psw-repeat"><b>Repeat Password</b></label>
    <input type="password" placeholder="Repeat Password" name="psw-repeat" required>
    
   
    <p>By creating an account you agree to our <a href="#" style="color:dodgerblue">Terms & Privacy</a>.</p>

    <div class="clearfix">
      
      <button type="submit" class="signupbtn" name="register">Sign Up</button>
    </div>
      </div>
    </div>


    
      <!-- ################################################################################################ -->
   

    
  </main>
</div>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
  <div class="wrapper row4 bgded overlay" style="background-color: black;">
  <footer id="footer" class="hoc clear"> 
    
    <div class="one_third first">
    
     
      
      <ul class="faico clear" style="text-align: center;">
        <li><a class="faicon-facebook" href="https://www.facebook.com/h.c.hardik"><i class="fa fa-facebook"></i></a></li>
        <li><a class="faicon-instagram" href="https://www.instagram.com/hc___the_conjuror/?hl=en"><i class="fa fa-instagram"></i></a></li>
        <li><a class="faicon-linkedin" href="https://www.linkedin.com/in/hardik-chauhan-553160138/"><i class="fa fa-linkedin"></i></a></li>
       </ul>
    </div>
    <div class="one_third" >
     
      <ul class="nospace linklist contact">
        <li><i class="fa fa-map-marker"></i>
          <address>
          9 Falkirk Street, Blockhouse Bay, Auckland, 0600
          </address>
        </li>
        
      </ul>
    </div>
    <div class="one_third" style="text-align: center;">
      
      <ul class="nospace linklist">
        <li>
          <article>
            
            <p class="nospace">Copyright &copy; 2018 - All Rights Reserved</p>
             <p class="nospace">Made by <a target="_blank" href="https://www.facebook.com/h.c.hardik" >Hardik Chauhan</a> with ❤</p>
          </article>
        </li>
        
      </ul>
    </div>
    
  </footer>
  </div>
  <!-- ################################################################################################ -->
  <!-- ################################################################################################ -->
  <!-- ###################################################################### ########################## -->
  <a id="backtotop" href="#top"><i class="fa fa-chevron-up"></i></a>
  <!-- JAVASCRIPTS -->
  <script src="../layout/scripts/jquery.min.js"></script>
  <script src="../layout/scripts/jquery.backtotop.js"></script>
  <script src="../layout/scripts/jquery.mobilemenu.js"></script>
  <script src="layout/scripts/jquery.flexslider-min.js"></script>


  <!--PHP-->


</body>



</html>