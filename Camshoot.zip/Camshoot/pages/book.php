<!DOCTYPE html>

<html>
<head>
<title>CAMSHOOT | Book a Photographer</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link href="../layout/styles/layout.css" rel="stylesheet" type="text/css" media="all">
<style type="text/css">

</style>
</head>
<body id="top">
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- Top Background Image Wrapper -->
<div class="bgded overlay" style="background-image:url('../images/demo/backgrounds/01.jpg');"> 
  <!-- ################################################################################################ -->
  <div class="wrapper row0">
    <div id="topbar" class="hoc clear"> 
      
      <div class="fl_left">
        <ul class="nospace">
          <li><i class="fa fa-phone"></i> +64 223944532</li>
          <li><i class="fa fa-envelope-o"></i> hc9555@gmail.com</li>
        </ul>
      </div>
      <div class="fl_right">
        <ul class="nospace">
          <li><a href="../index.html"><i class="fa fa-lg fa-home"></i></a></li>
          <li><a href="login.php">Login</a></li>
          <li><a href="user.php">Register</a></li>
        </ul>
      </div>
      <!-- ################################################################################################ -->
    </div>
  </div>
  </div>
  <!-- ################################################################################################ -->
  <!-- ################################################################################################ -->
  <!-- ################################################################################################ -->
  <div class="wrapper row1">
    <header id="header" class="hoc clear"> 
      <!-- ################################################################################################ -->
      <div id="logo" class="fl_left">
        <h1><a href="../index.html"><img src="../logo.png" alt="logo" style="width: 250px; height: auto;"></a></h1>
      </div>
      <nav id="mainav" class="fl_right"><br>
        <ul class="clear">
          <li><a href="../index.html">Home</a></li>
          <li><a class="drop" href="#">Gallery</a>
            <ul>
              <li><a href="gallery.html">Fashion & Modeling</a></li>

              <li><a href="nature.html">Nature</a></li>
              <li><a href="b&w.html">Black and White</a></li>
              
            </ul>
          </li>
             <li><a href="events.html">Competition & Events</a></li>

           <li class="active"><a href="book.php">Book a photographer</a></li>
          <li><a href="contact.php">Contact Us</a></li>
        </ul>
      </nav>
      <!-- ################################################################################################ -->
    </header>
  </div>
  <!-- ################################################################################################ -->
</div>
<!-- End Top Background Image Wrapper -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<div class="wrapper row2">
  <div id="breadcrumb" class="hoc clear"> 
    <!-- ################################################################################################ -->
    <ul>
      <li><a href="../index.html">Home</a></li>
      <li><a href="contact.php">Book a Photographer</a></li>
    </ul>
    <!-- ################################################################################################ -->
  </div>
</div>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<div class="wrapper row3">
  <main class="hoc container clear"> 
    
    
      <!-- #################################################################################-->
      <div id="comments">
        
        
        <h2>Online Booking</h2>
        <form method="post" action="book.php">
          <div class="one_third first">
            <label for="name">Name <span>*</span></label>
            <input type="text" name="name" id="name" value="" size="22" required>
          </div>
          <div class="one_third">
            <label for="email">E-Mail <span>*</span></label>
            <input type="email" name="email" id="email" value="" size="22" required>
          </div>
          <div class="one_third first">
            <label for="mobile">Mobile no. <span>*</span></label>
            <input type="tel" name="mobile" id="mobile" value="" size="22" required>
          </div>
          <div class="one_third">
            <label for="address">Address <span>*</span></label>
            <input type="address" name="address" id="address" value="" size="22" required>
          </div>

        <div class="one_third first">
            <label for="date">Date from <span>*</span></label>
            <input type="datetime-local" name="datetime" id="date" value="" size="20" required>
          </div>
          <div class="one_third">
            <label for="date2">Date to <span>*</span></label>
            <input type="datetime-local" name="datetimeto" id="date2" value="" size="20" required>
          </div>
          
          <div class="block clear">
            <label for="photographerfor">Occasion<span>*</span></label>
            <textarea name="photographerfor" id="comment" cols="10" rows="1" required=""></textarea>
          </div>
            <div class="block clear">
            <label for="comment">Additional</label>
            <textarea name="comment" id="comment" cols="10" rows="3"></textarea>
          </div>
          <div>
            <input type="submit" name="submit" value="Submit Form" style="background-color: #EA2C5A; border-radius: 5px; border: 1px solid #EA2C5A; padding: 15px;">
            
            
          </div>
        </form>


      </div>
      <!-- ################################################################################################ -->
   

    
  </main>
</div>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
  <div class="wrapper row4 bgded overlay" style="background-color: black;">
  <footer id="footer" class="hoc clear"> 
    
    <div class="one_third first">
    
     
      
      <ul class="faico clear" style="text-align: center;">
        <li><a class="faicon-facebook" href="https://www.facebook.com/h.c.hardik"><i class="fa fa-facebook"></i></a></li>
        <li><a class="faicon-instagram" href="https://www.instagram.com/hc___the_conjuror/?hl=en"><i class="fa fa-instagram"></i></a></li>
        <li><a class="faicon-linkedin" href="https://www.linkedin.com/in/hardik-chauhan-553160138/"><i class="fa fa-linkedin"></i></a></li>
       </ul>
    </div>
    <div class="one_third" >
     
      <ul class="nospace linklist contact">
        <li><i class="fa fa-map-marker"></i>
          <address>
          9 Falkirk Street, Blockhouse Bay, Auckland, 0600
          </address>
        </li>
        
      </ul>
    </div>
    <div class="one_third" style="text-align: center;">
      
      <ul class="nospace linklist">
        <li>
          <article>
            
            <p class="nospace">Copyright &copy; 2018 - All Rights Reserved</p>
             <p class="nospace">Made by <a target="_blank" href="https://www.facebook.com/h.c.hardik" >Hardik Chauhan</a> with ❤</p>
          </article>
        </li>
        
      </ul>
    </div>
    
  </footer>
  </div>
  <!-- ################################################################################################ -->
  <!-- ################################################################################################ -->
  <!-- ###################################################################### ########################## -->
  <a id="backtotop" href="#top"><i class="fa fa-chevron-up"></i></a>
  <!-- JAVASCRIPTS -->
  <script src="../layout/scripts/jquery.min.js"></script>
  <script src="../layout/scripts/jquery.backtotop.js"></script>
  <script src="../layout/scripts/jquery.mobilemenu.js"></script>
  <script src="layout/scripts/jquery.flexslider-min.js"></script>


  <!--PHP-->
<?php
if(isset($_POST['submit']))
{
 $name = $_POST['name'];
 $visitor_email = $_POST['email'];
 $mobile = $_POST['mobile'];
 $address = $_POST['address'];
 $from = $_POST['datetime'];
 $to = $_POST['datetimeto'];
 $photographerfor = $_POST['photographerfor'];
 $comment = $_POST['comment'];

 $email_from = 'hc9555@gmail.com';

 $email_subject = "Booking Query";

 $email_body = "name: $name.\n"."Email: $visitor_email.\n"."Mobile: $mobile.\n"."address: $address.\n"."Date and time FROM: $from.\n"."Date and time TO: $to.\n"."Ocassion: $photographerfor.\n"."Message: $comment.\n";

 $to = "hc9555@gmail.com";
 $headers = "From: $email_from \r\n";


 
 mail($to,$email_subject,$email_body,$headers) or die("Error! Try Again");
 echo '<script type="text/javascript">alert("Thank You!!! We will contact you via email for the BEST RATE and appointed PHOTOGRAPHER.")</script>';
 }
 else
 {

 }

 ?>

</body>



</html>