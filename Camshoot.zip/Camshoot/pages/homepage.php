<?php
  session_start();
  require_once('dbconfig/config.php');
  
?>





<!DOCTYPE html>
<html>
<head>
<title><?php echo $_SESSION['email']; ?></title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link href="../layout/styles/layout.css" rel="stylesheet" type="text/css" media="all">
<style type="text/css">
  
  .logout_button{font-size: 17px;
    padding: 10px; background-color: #EA2C5A; width: 100%; margin-top: 30px; border:1px solid black;
    border-radius: 10px; cursor: pointer;
    color: black;
  }
.sub111{
  background-color: #EA2C5A; border: 1px solid #EA2C5A; border-radius: 10px; padding: 10px; width: 100%; cursor: pointer;
}
  .logout_button:hover,
  .sub111:hover
  {
    color: grey;
    background-color: black;
  }



</style>
</head>
<body id="top">
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- Top Background Image Wrapper -->
<div class="bgded overlay" style="background-image:url('../images/demo/backgrounds/01.jpg');"> 
  <!-- ################################################################################################ -->
  <div class="wrapper row0">
    <div id="topbar" class="hoc clear"> 
      
      <div class="fl_left">
        <ul class="nospace">
          <li><i class="fa fa-phone"></i> +64 223944532</li>
          <li><i class="fa fa-envelope-o"></i> hc9555@gmail.com</li>
        </ul>
      </div>
      <div class="fl_right">
        <ul class="nospace">
          <li><a href="../index.html"><i class="fa fa-lg fa-home"></i></a></li>
          <li>Welcome, <i>(<?php echo $_SESSION['email']; ?>)</i></li>
          
        </ul>
      </div>
      <!-- ################################################################################################ -->
    </div>
  </div>
  </div>
  <!-- ################################################################################################ -->
  <!-- ################################################################################################ -->
  <!-- ################################################################################################ -->
  <div class="wrapper row1">
    <header id="header" class="hoc clear"> 
      <!-- ################################################################################################ -->
      <div id="logo" class="fl_left">
        <h1><a href="../index.html"><img src="../logo.png" alt="logo" style="width: 250px; height: auto;"></a></h1>
      </div>
      <nav id="mainav" class="fl_right"><br>
        <ul class="clear">
          <li><a href="homepage.php">Home</a></li>
          <li><a class="drop" href="#">Gallery</a>
            <ul>
              <li><a href="gallery.html">Fashion & Modeling</a></li>

              <li><a href="nature.html">Nature</a></li>
              <li><a href="b&w.html">Black and White</a></li>
              
            </ul>
          </li>

          
           <li><a href="events.html">Competition & Events</a></li>

           <li><a href="book.php">Book a photographer</a></li>
          <li><a href="contact.php">Contact Us</a></li>
        </ul>
      </nav>
      <!-- ################################################################################################ -->
    </header>
  </div>
  <!-- ################################################################################################ -->
</div>
<!-- End Top Background Image Wrapper -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<div class="wrapper row2">
  <div id="breadcrumb" class="hoc clear"> 
    <!-- ################################################################################################ -->
    
    <!-- ################################################################################################ -->
  </div>
</div>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<div class="wrapper row3" style="margin: auto;">
  <main class="hoc container clear"> 
    <!-- main body -->
    <!-- ################################################################################################ -->
    <div class="content three_quarter first" style="margin: auto; width: 70%; float: left; text-align: left;"> 
      <!-- ################################################################################################ -->
   <form action="homepage.php" method="post" enctype="multipart/form-data" style="float: left;">
    <h1 style="word-spacing: 7px;">Select image to upload</h1>
    <br>
    <br>
    <div style="background-color: lightgrey; padding: 10px; border-radius: 10px;"><input type="file" name="profile" id="fileToUpload" style="font-size: 12px;">
    <br>

    <input type="submit" value="Upload Image" name="add1" class="sub111">
    </div>
</form>
<?php
$mail_id = @$_SESSION['email'];
    if($mail_id){
if(isset($_POST['add1']))
{
  $filetmp = $_FILES["profile"]["tmp_name"];
  $filename = $_FILES["profile"]["name"];
  $filetype = $_FILES["profile"]["type"];
  $filepath = "../users/$mail_id/".$filename;
  
  $filename = preg_replace('#[^a-z.0-9]#i', '$mail_id', $filename);
  
  move_uploaded_file($filetmp,$filepath);
  
  $sql = "INSERT INTO upload_img (img_name,img_path,img_type,mail_id) VALUES ('$filename','$filepath','$filetype','$mail_id')";
  $result = mysqli_query($con,$sql);
  echo "<script>(function(){alert('Upload Sucess!!!!');})();</script>";
}
}else
{}
?>

</div>
    <!-- ################################################################################################ -->
    <!-- ################################################################################################ -->
    <div class="sidebar one_quarter" style="margin: auto; width:30%; float: right; text-align: left;"> 
      <!-- ################################################################################################ -->
    
      <!-- ################################################################################################ -->
      <h6>Options</h6>
      <nav class="sdb_holder">
        <ul>
          
          <li><a href="myphoto.php">My Photos</a></li>
          <!--<li><a href="accountdetail.php">Change Password</a></li></ul>
      -->
   </nav>

          <form action="login.php" method="post"><a href="logout.php"><button class="logout_button" type="submit">LOG OUT</button></a></form>
             
 </div>
      
      <!-- ################################################################################################ -->
    
    <!-- ################################################################################################ -->
    <!-- / main body -->
    <div class="clear"></div>
  </main>
</div>








 





<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
  <div class="wrapper row4 bgded overlay" style="background-color: black;">
  <footer id="footer" class="hoc clear"> 
    
    <div class="one_third first">
    
     
      
      <ul class="faico clear" style="text-align: center;">
        <li><a class="faicon-facebook" href="https://www.facebook.com/h.c.hardik"><i class="fa fa-facebook"></i></a></li>
        <li><a class="faicon-instagram" href="https://www.instagram.com/hc___the_conjuror/?hl=en"><i class="fa fa-instagram"></i></a></li>
        <li><a class="faicon-linkedin" href="https://www.linkedin.com/in/hardik-chauhan-553160138/"><i class="fa fa-linkedin"></i></a></li>
       </ul>
    </div>
    <div class="one_third" >
     
      <ul class="nospace linklist contact">
        <li><i class="fa fa-map-marker"></i>
          <address>
          9 Falkirk Street, Blockhouse Bay, Auckland, 0600
          </address>
        </li>
        
      </ul>
    </div>
    <div class="one_third" style="text-align: center;">
      
      <ul class="nospace linklist">
        <li>
          <article>
            
            <p class="nospace">Copyright &copy; 2018 - All Rights Reserved</p>
             <p class="nospace">Made by <a target="_blank" href="https://www.facebook.com/h.c.hardik" >Hardik Chauhan</a> with ❤</p>
          </article>
        </li>
        
      </ul>
    </div>
    
  </footer>
  </div>
  <!-- ################################################################################################ -->
  <!-- ################################################################################################ -->
  <!-- ###################################################################### ########################## -->
  <a id="backtotop" href="#top"><i class="fa fa-chevron-up"></i></a>
  <!-- JAVASCRIPTS -->
  <script src="../layout/scripts/jquery.min.js"></script>
  <script src="../layout/scripts/jquery.backtotop.js"></script>
  <script src="../layout/scripts/jquery.mobilemenu.js"></script>
  <script src="layout/scripts/jquery.flexslider-min.js"></script>


 
</body>



</html>