<?php 
session_start();
require_once('dbconfig/config.php');
session_destroy(); 
header("location: login.php");
?>